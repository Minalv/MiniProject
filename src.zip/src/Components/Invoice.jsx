
import { Table, TableHead, TableBody, TableRow, TableCell, Button,styled, Typography } from '@mui/material';

const StyledTable = styled(Table)({
    width: '80%',
    margin: 20,
    marginTop:40,
    '& > thead > tr > th':{
        background: '#000',
        color: '#FFFFFF',
        fontSize: 18
    },
    '& > thead > tr > td': {
        fontSize:16
    },
    '& > tbody > p' : {
        fontSize: 18,
        marginTop: 15
    }

})

const Invoice = ({invoice, removeInvoice}) => {


    return (
        <StyledTable>
         {/* <Table> */}
            <TableHead>
                <TableRow>
                    <TableCell>Vendor</TableCell>
                    <TableCell>Product</TableCell>
                    <TableCell>Amount</TableCell>
                    <TableCell>Date</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Action</TableCell>
                </TableRow>
            </TableHead>
            <TableBody>
                {
                   invoice && Array.isArray(invoice) && invoice.length > 0 ? 
                   invoice.map(invoice => (
                    <TableRow>
                        <TableCell>{invoice.vendor}</TableCell>
                        <TableCell>{invoice.product}</TableCell>
                        <TableCell>{invoice.amount}</TableCell>
                        <TableCell>{invoice.date}</TableCell>
                        <TableCell>{invoice.action}</TableCell>
                        <TableCell>
                            <Button 
                                variant="contained" 
                                color="success"
                                onClick={() => removeInvoice(invoice.id)}
                                >Mark Done</Button>
                                
                        </TableCell>
                    </TableRow>
                   )) 
                   :
                   <Typography>No Pending Invoices</Typography>
                }
            </TableBody>
         {/* </Table> */}
         </StyledTable>
    )
}

export default Invoice;