
import { AppBar, Toolbar } from '@mui/material'; 
import logo from './logo.png';
const Header = () => {
    //const logo = "C:\Users\singh\Documents\javaProject\client";
    return (
        <AppBar position= "static">
            <Toolbar>
                <img src = {logo} alt = "logo" style = {{width :100 }}/>
            </Toolbar>
        </AppBar>
    )
}

export default Header;