import axios from 'axios';
const API_URL = "http://localhost:8080"; 
export const saveInvoice = async (payload) => {
    try {
        //request.open('POST', endpoint);
        return await axios.post(`${API_URL}/invoice`, payload); // Use backticks (`) for string interpolation
    } catch (error) {
        console.log('Error: ', error.message);
        // return error.response.data;
    }
}

export const getAllInvoice = async() => {
    try {
        return await axios.get(`${API_URL}/invoice`);
    } catch (error) {
        console.log('Error: ', error.message);
        // return error.response.data;
    }
} 


export const deleteInvoice = async(id) => {
    try {
        return await axios.delete(`${API_URL}/invoice/${id}`);
    } catch (error) {
        console.log('Error: ', error.message);
        // return error.response.data;
    }
} 
